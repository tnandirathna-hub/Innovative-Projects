# E-Professionals.lk — Full Prototype (Postgres + Magic Link)

Next.js 14 • Tailwind • NextAuth (Email Magic Link + Credentials) • Prisma (Postgres).

## Quick Start (Local)
```bash
npm install
cp .env.example .env
# Fill DATABASE_URL with your Postgres connection string
# Fill SMTP settings for magic links (or skip and use credentials login only)
npx prisma db push
npm run db:seed
npm run dev
```

Admin (seeded): `admin@e-professionals.lk` / `Admin@123`

## Deploy to Vercel
1. Push this project to GitHub (public or private).
2. Click the button below **after you replace the repository URL with your own**:

[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new/clone?repository-url=REPLACE_WITH_YOUR_GITHUB_REPO_URL&project-name=e-professionals&repository-name=e-professionals)

3. In Vercel → Project Settings → **Environment Variables**:
   - `DATABASE_URL` → your Postgres connection string (Neon/Supabase/Railway)
   - `NEXTAUTH_SECRET` → generate a strong secret
   - `NEXTAUTH_URL` → e.g., `https://e-professionals.vercel.app`
   - `EMAIL_SERVER_HOST`, `EMAIL_SERVER_PORT`, `EMAIL_SERVER_USER`, `EMAIL_SERVER_PASSWORD`, `EMAIL_FROM`

4. Run migrations/seed on Vercel (via Deploy Hooks or one-off command):
   ```bash
   npx prisma migrate deploy
   npm run db:seed
   ```

5. Connect your domain `www.E-Professionals.lk` in Vercel.
