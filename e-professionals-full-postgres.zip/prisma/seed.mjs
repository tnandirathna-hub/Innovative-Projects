import { PrismaClient } from '@prisma/client'
import bcrypt from 'bcryptjs'
const prisma = new PrismaClient()

const services = [
  { key: 'ict', title: 'ICT Solutions', order: 1, icon:'Cpu', items: JSON.stringify(['Software Development','System Integration','Cloud Services','Cybersecurity']) },
  { key: 'analysis', title: 'Business Analysis', order: 2, icon:'Search', items: JSON.stringify(['Feasibility Studies','Process Optimization','Data Analytics']) },
  { key: 'finance', title: 'Financial & Risk', order: 3, icon:'Landmark', items: JSON.stringify(['Fund Management','Risk Assessments','Tax Planning']) },
  { key: 'iso', title: 'ISO Introduction & Implementation', order: 4, icon:'BadgeCheck', items: JSON.stringify(['ISO 9001 Quality','ISO 14001 Environmental','ISO 45001 Health & Safety','ISO 27001 Information Security']) },
  { key: 'audit', title: 'Specialized Audits', order: 5, icon:'FileText', items: JSON.stringify(['Forensic Audits','HR Audits','Compliance Audits','Operational Audits']) },
  { key: 'legal', title: 'Legal & Secretarial', order: 6, icon:'Scale', items: JSON.stringify(['Company Incorporation','Contracts','Regulatory Compliance']) },
  { key: 'transform', title: 'Business Transformation', order: 7, icon:'Workflow', items: JSON.stringify(['Process Re-engineering','Digital Transformation','Change Management']) },
  { key: 'agro', title: 'Sustainability & Agro', order: 8, icon:'Recycle', items: JSON.stringify(['Agro Projects','Sustainable Practices','Environmental Solutions']) },
  { key: 'realestate', title: 'Real Estate', order: 9, icon:'Building2', items: JSON.stringify(['Property Development','Valuation','Leasing']) },
  { key: 'trade', title: 'Trade & Logistics', order: 10, icon:'Truck', items: JSON.stringify(['Import/Export','Supply Chain','Customs Advisory']) },
]

async function main() {
  for (const s of services) {
    await prisma.service.upsert({ where:{ key: s.key }, update: s, create: s })
  }
  const adminEmail = 'admin@e-professionals.lk'
  const pwd = await bcrypt.hash('Admin@123',10)
  await prisma.user.upsert({
    where: { email: adminEmail },
    update: {},
    create: { email: adminEmail, password: pwd, role: 'ADMIN', name: 'Admin' }
  })
  console.log('Seeded services and admin user.')
}

main().finally(()=>prisma.$disconnect())
