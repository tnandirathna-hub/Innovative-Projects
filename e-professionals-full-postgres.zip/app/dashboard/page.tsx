'use client'
const STEPS = ['Inquiry Submission','Thorough Evaluation','Site Visit & Assessment','Draft Action Plan','NDA Signing','Comprehensive Proposal','Client Acceptance','Project Kickoff','Interim Reporting','Progress Reviews','Handover','Post-Implementation Review']
export default function Dashboard(){
  const agreements = [{ id:'1023', status:'Signed' }, { id:'1044', status:'Awaiting Signature' }]
  const invoices = [{ id:'3021', status:'Pending' }]
  return (
    <section className="mx-auto max-w-7xl px-4 py-12">
      <h2 className="text-3xl font-extrabold">User Dashboard</h2>
      <div className="grid md:grid-cols-2 gap-6 mt-6">
        <div className="rounded-2xl border p-6 bg-white shadow-sm">
          <div className="font-semibold mb-2">My 12-Step Workflow</div>
          <ol className="text-sm space-y-1">
            {STEPS.map((step, idx) => (<li key={idx} className="flex items-center gap-2">• {step}</li>))}
          </ol>
        </div>
        <div className="rounded-2xl border p-6 bg-white shadow-sm">
          <div className="font-semibold mb-2">My Agreements & Invoices</div>
          <ul className="text-sm space-y-2">
            {agreements.map(a=> (<li key={a.id} className="flex justify-between"><span>E-Agreement #{a.id}</span><span>{a.status}</span></li>))}
            {invoices.map(i=> (<li key={i.id} className="flex justify-between"><span>Invoice #{i.id}</span><span>{i.status}</span></li>))}
          </ul>
        </div>
      </div>
    </section>
  )
}
