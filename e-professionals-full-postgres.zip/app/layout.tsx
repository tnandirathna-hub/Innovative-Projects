import './globals.css'
import Link from 'next/link'

export const metadata = { title: 'E-Professionals.lk', description: 'Full Prototype (Postgres)' }

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="min-h-screen bg-gradient-to-b from-white to-blue-50 text-zinc-900">
        <header className="sticky top-0 z-20 backdrop-blur bg-white/80 border-b">
          <div className="mx-auto max-w-7xl px-4 py-3 flex items-center justify-between">
            <div className="font-extrabold tracking-tight text-blue-700">E-Professionals.lk</div>
            <nav className="hidden md:flex items-center gap-6 text-sm">
              <Link className="hover:underline" href="/">Home</Link>
              <Link className="hover:underline" href="/auth">Login</Link>
              <Link className="hover:underline" href="/dashboard">Dashboard</Link>
              <Link className="hover:underline" href="/admin">Admin</Link>
            </nav>
          </div>
        </header>
        {children}
      </body>
    </html>
  )
}
