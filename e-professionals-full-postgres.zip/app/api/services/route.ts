import { NextResponse } from 'next/server'
import { PrismaClient } from '@prisma/client'
const prisma = new PrismaClient()
export async function GET() {
  const rows = await prisma.service.findMany()
  const data = rows.map(r => ({ key: r.key, title: r.title, order: r.order, items: JSON.parse(r.items), icon: r.icon ?? undefined }))
  return NextResponse.json(data)
}
