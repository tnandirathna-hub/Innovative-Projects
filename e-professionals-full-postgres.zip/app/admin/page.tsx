export default function Admin(){
  return (
    <section className="mx-auto max-w-7xl px-4 py-12">
      <h2 className="text-3xl font-extrabold">Admin Dashboard (Prototype)</h2>
      <div className="mt-6 grid md:grid-cols-3 gap-6">
        <div className="rounded-2xl border p-6 bg-white shadow-sm"><div className="font-semibold">Pending Verifications</div><p className="mt-2 text-sm">12 new KYC forms awaiting review.</p></div>
        <div className="rounded-2xl border p-6 bg-white shadow-sm"><div className="font-semibold">E-Agreements</div><p className="mt-2 text-sm">8 contracts pending digital signature.</p></div>
        <div className="rounded-2xl border p-6 bg-white shadow-sm"><div className="font-semibold">Invoices</div><p className="mt-2 text-sm">5 invoices pending payment gateway processing.</p></div>
      </div>
    </section>
  )
}
