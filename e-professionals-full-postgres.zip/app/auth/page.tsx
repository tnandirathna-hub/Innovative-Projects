'use client'
import { useState } from 'react'
import { signIn } from 'next-auth/react'

export default function AuthPage(){
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')

  async function register(){
    await fetch('/api/register', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ email, password }) })
    await signIn('credentials', { email, password, callbackUrl: '/dashboard' })
  }
  async function login(){
    await signIn('credentials', { email, password, callbackUrl: '/dashboard' })
  }
  async function magic(){
    await signIn('email', { email, callbackUrl: '/dashboard' })
  }

  return (
    <div className="mx-auto max-w-md px-4 py-12">
      <h2 className="text-2xl font-bold mb-4">Login / Register</h2>
      <input value={email} onChange={e=>setEmail(e.target.value)} placeholder="Email" className="w-full rounded-lg border px-3 py-2 mb-3"/>
      <input value={password} type="password" onChange={e=>setPassword(e.target.value)} placeholder="Password (optional for magic link)" className="w-full rounded-lg border px-3 py-2 mb-3"/>
      <div className="flex flex-wrap gap-3">
        <button onClick={login} className="rounded-2xl px-5 py-3 font-semibold border border-blue-700 text-blue-700">Login</button>
        <button onClick={register} className="rounded-2xl px-5 py-3 font-semibold bg-blue-700 text-white">Register</button>
        <button onClick={magic} className="rounded-2xl px-5 py-3 font-semibold border border-zinc-300">Send Magic Link</button>
      </div>
    </div>
  )
}
