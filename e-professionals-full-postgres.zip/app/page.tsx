'use client'
import React, { useState, useEffect } from 'react'

type Service = { key: string, title: string, items: string[], order: number, icon?: string }

export default function Page(){
  const [disclaimerOpen, setDisclaimerOpen] = useState(true)
  const [showExecutiveSummary, setShowExecutiveSummary] = useState(false)
  const [services, setServices] = useState<Service[]>([])
  const [expanded, setExpanded] = useState<string | null>(null)

  useEffect(()=>{ fetch('/api/services').then(r=>r.json()).then(setServices) },[])

  return (
    <main>
      {showExecutiveSummary && (
        <section className="mx-auto max-w-5xl px-4 py-12">
          <h2 className="text-3xl font-extrabold mb-4">Executive Summary</h2>
          <p className="text-zinc-700 leading-relaxed mb-8">
            E-Professionals.lk connects service providers and seekers with KYC verification, e-agreements, AI-assisted matching, and a structured 12-step workflow. Registered users can log in to manage agreements, invoices, and progress.
          </p>
          <h3 className="text-2xl font-bold mb-4">Services Offered</h3>
          <div className="space-y-4 mb-8">
            {services.sort((a,b)=>a.order-b.order).map((srv) => (
              <div key={srv.key} className="rounded-xl border bg-white shadow-sm">
                <button className="flex items-center justify-between w-full p-4 text-left"
                  onClick={() => setExpanded(expanded === srv.key ? null : srv.key)}>
                  <div className="flex items-center gap-3">
                    <span className="inline-block h-2 w-2 rounded-full bg-blue-700" />
                    <span className="font-medium text-sm">{srv.title}</span>
                  </div>
                  <span className="text-xs text-zinc-500">{expanded === srv.key ? 'Hide' : 'View'}</span>
                </button>
                {expanded === srv.key && (
                  <ul className="px-8 pb-4 text-sm list-disc text-zinc-600">
                    {srv.items.map((d, i) => <li key={i}>{d}</li>)}
                  </ul>
                )}
              </div>
            ))}
          </div>
          <div className="text-center">
            <a href="/auth"><button className="rounded-2xl px-5 py-3 font-semibold shadow-md hover:shadow-lg transition bg-blue-700 text-white">Continue to Platform</button></a>
          </div>
        </section>
      )}
      {disclaimerOpen && (
        <div className="fixed inset-0 z-30 grid place-items-center bg-black/40 p-4">
          <div className="max-w-xl w-full rounded-3xl bg-white p-6 shadow-2xl">
            <div className="flex items-center gap-2"><div className="font-bold text-blue-700">Disclaimer</div></div>
            <p className="mt-3 text-sm text-zinc-700">
              This is a full-featured prototype. By continuing, you acknowledge this demo illustrates KYC, NDA, e-signatures, AI matching, and workflows only.
            </p>
            <div className="mt-5 flex justify-end gap-3">
              <button className="rounded-2xl px-5 py-3 font-semibold border border-blue-700 text-blue-700" onClick={() => setDisclaimerOpen(false)}>I Understand</button>
              <button className="rounded-2xl px-5 py-3 font-semibold bg-blue-700 text-white" onClick={() => { setDisclaimerOpen(false); setShowExecutiveSummary(true); }}>Enter Platform</button>
            </div>
          </div>
        </div>
      )}
    </main>
  )
}
